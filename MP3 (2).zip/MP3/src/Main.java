import edu.ncat.brickbreakerbackend.BrickRow;
import edu.ncat.brickbreakerbackend.GameProfiles;
import edu.ncat.brickbreakerbackend.Level;
import edu.ncat.brickbreakerbackend.PlayerProfile;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {

        try {
            Level level = new Level(1, 5); // Level 1 with 5 rows
            for(int i = 0; i < 5; i++) {
                BrickRow row = new BrickRow(10, Color.RED, "11111111");
                level.setBrickRow(i, row);
            }
            GameProfiles profiles = new GameProfiles();
            PlayerProfile player = new PlayerProfile("Test Player");
            profiles.addPlayerProfile(player);
            profiles.setSelectedProfile(player);
            GameBoard gameBoard = new GameBoard(
                    new Level[]{level},
                    profiles,
                    "test_profiles.txt"
            );
            Scene scene = new Scene(gameBoard, 800, 600);
            primaryStage.setTitle("Brick Breaker");
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.show();
        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}