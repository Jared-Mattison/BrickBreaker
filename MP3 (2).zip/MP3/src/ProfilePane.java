//Jared Mattison
//November 13th, 2024
//This code is a JavaFX GUI for the Brick Breaker game that is designed to
// manage player profiles and configs
import edu.ncat.brickbreakerbackend.GameProfiles;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ProfilePane extends VBox { ////Properties for player profiles
    private GameProfiles profiles; //Instance of GameProfiles
    private String profileFileName; //Stores profile data
    private String configFileName; //Config file name for game settings
    private Node controls; //Placeholder for controls
   //UI controls
    private ComboBox<String> profileSelection; //Dropdown box
    private TextField newProfile; //Text field to enter a new name
    private Button searchName; //Button to search for the name entered
    private Button createProfile; //Button to create a new profile
    private Label statusLabel; //Label to display a status message
    private ObservableList<String> users = FXCollections.observableArrayList(); //List of the player names

    //Constructor to initialize the ProfilePane with the filenames
    public ProfilePane(String profileFileName, String configFileName) {
        this.profileFileName = profileFileName;
        this.configFileName = configFileName;
        this.profiles = new GameProfiles();

        profileComponents(); //Initializes components
        setupLayout(); //Arrange the components in my custom layout
        eventHandlers(); //Button click events
    }
    //Initialize components in ProfilePane
    private void profileComponents() {
        profileSelection = new ComboBox<>();
        newProfile = new TextField();
        searchName = new Button("OK");
        createProfile = new Button("Create New Profile");
        statusLabel = new Label("");

        newProfile.setPromptText("Enter Player Name");
        profileSelection.setPromptText("Select Profile");

        updatePlayerSelection(); //Fills the box with the available profiles
    }
    //Set up the layout of the controls
    private void setupLayout() {
        //Creates labels in bold
        Label currentSelectionLabel = new Label("Current Player Selection");
        currentSelectionLabel.setStyle("-fx-font-weight: bold;");

        Label newRegistrationLabel = new Label("New Player Registration");
        newRegistrationLabel.setStyle("-fx-font-weight: bold;");
        //Layout of current profile selection
        HBox currentSelectionControls = new HBox(10, profileSelection, searchName);
        VBox currentSelectionBox = new VBox(5, currentSelectionLabel, currentSelectionControls);
        currentSelectionBox.setPadding(new Insets(10));
        currentSelectionBox.setStyle("-fx-border-color: black; -fx-border-width: 1; -fx-border-radius: 5;");
        //Layout for new profile creation section
        HBox newCreationControls = new HBox(10, newProfile, createProfile, statusLabel);
        VBox newCreationBox = new VBox(5, newRegistrationLabel, newCreationControls);
        newCreationBox.setPadding(new Insets(10));
        newCreationBox.setStyle("-fx-border-color: black; -fx-border-width: 1; -fx-border-radius: 5;");
        //Sets the width for the controls to make sure it doesn't take up too much space
        profileSelection.setMaxWidth(200);
        newProfile.setMaxWidth(150);
    //Add elements to ProfilePane
        this.setSpacing(10);
        this.getChildren().addAll(currentSelectionBox, newCreationBox);
    }
    //Define event handlers
    private void eventHandlers() {
        searchName.setOnAction(e -> searchUser()); //Search button event

        createProfile.setOnAction(e -> createNewPlayer()); //Create profile button event
    }
    //Action to search for profiles and select
    private void searchUser() {
        String selectedUser = profileSelection.getValue();
        if (selectedUser == null || selectedUser.isEmpty()) {
            statusLabel.setText("Select a player."); //Message shown if no player is chosen
        } else {
            boolean playerExists = true;
            if (playerExists) {
                statusLabel.setText("Player: " + selectedUser); //Displays selected players name
                openProfileWindow(selectedUser); //Opens new window with profile details
            } else {
                statusLabel.setText("Player name does not exist."); //Displays if player is not found
            }
        }
    }
    //Action to create a new profile
    private void createNewPlayer() {
        String newUser = newProfile.getText();
        if (newUser.isEmpty()) {
            statusLabel.setText("Enter your player name."); //Message is no name is entered
        } else {
            boolean playerExists = users.contains(newUser); //Checks if player name exists
            if (playerExists) {
                statusLabel.setText("Entered name is already taken."); //Message when name is taken
                statusLabel.setStyle("-fx-text-fill: red;");
            } else {
                users.add(newUser); //Adds new player to the list
                updatePlayerSelection(); //Resest with an updated list
                statusLabel.setText("New player: " + newUser);
                newProfile.clear(); //Clears input field
            }
        }
    }
    //Opens a new window that displays the players profile
    private void openProfileWindow(String player) {
        Stage profileStage = new Stage();
        VBox profileBox = new VBox(10, new Label("Player Profile: " + player));
        Scene profileScene = new Scene(profileBox, 300, 200);
        profileStage.setTitle("Player Profile");
        profileStage.setScene(profileScene);
        profileStage.show();
    }
    //Updates the ComboBox with the list of profiles
    private void updatePlayerSelection() {
        profileSelection.setItems(users);
    }
}