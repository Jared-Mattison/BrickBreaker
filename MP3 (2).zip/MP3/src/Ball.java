import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.util.Random;

public class Ball extends Circle {
    private static final int RADIUS = 7;  // Ball's radius
    private static final int DEFAULT_SPEED = 5;  // Default speed of the ball
    private int speed;
    private double direction;

    public Ball(int paWidth, int paHeight, double dir) {
        super(RADIUS, Color.BLUE);  // Set the ball color to red
        this.setRadius(RADIUS);
        this.speed = DEFAULT_SPEED;  // Set default speed
        this.direction = dir;  // Set the initial direction
        this.setCenterX(paWidth / 2.0);  // Start ball at the horizontal center
        this.setCenterY(paHeight / 2.0);  // Start ball at the vertical center
    }

    // Move the ball in the current direction and speed
    public void move() {
        double deltaX = speed * Math.cos(Math.toRadians(direction));
        double deltaY = speed * Math.sin(Math.toRadians(direction));

        this.setCenterX(this.getCenterX() + deltaX);
        this.setCenterY(this.getCenterY() + deltaY);
    }

    // Get the top edge of the ball
    public int getTopEdge() {
        return (int) (this.getCenterY() - RADIUS);
    }

    // Get the bottom edge of the ball
    public int getBottomEdge() {
        return (int) (this.getCenterY() + RADIUS);
    }

    // Get the left edge of the ball
    public int getLeftEdge() {
        return (int) (this.getCenterX() - RADIUS);
    }

    // Get the right edge of the ball
    public int getRightEdge() {
        return (int) (this.getCenterX() + RADIUS);
    }

    // Launch the ball at a random angle between 40 and 140 degrees
    public void launch() {
        Random rand = new Random();
        direction = 40 + rand.nextInt(101);  // Random angle between 40 and 140 degrees
    }

    // Reset the ball to the paddle's position
    public void resetPosition(double paddleX, double paddleY) {
        this.setCenterX(paddleX + Paddle.PADDLE_WIDTH / 2.0);
        this.setCenterY(paddleY - RADIUS);  // Just above the paddle
        this.setVisible(true);
        this.launch();  // Give it a random direction
    }

    // Set visibility of the ball
    public void setBallVisibility(boolean visibility) {
        super.setVisible(visibility);
    }

    public void reverseVerticalDirection() {
        direction = 360 - direction;
    }

    // Reverse the horizontal direction of the ball
    public void reverseHorizontalDirection() {
        direction = 180 - direction;
    }
}
