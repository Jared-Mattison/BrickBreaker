import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;

public class ScorePane extends HBox {
    private int score;
    private Label lblScore;

    // Constructor to initialize the score pane
    public ScorePane() {
        this.score = 0; // Initialize score to 0
        lblScore = new Label("Score: " + score);
        lblScore.setFont(new Font(25)); // Set the font size for the score display
        this.getChildren().add(lblScore); // Add the label to the ScorePane
    }

    // Set the score
    public void setScore(int score) {
        this.score = score;
        lblScore.setText("Score: " + score); // Update the displayed score
    }

    // Get the current score
    public int getScore() {
        return score;
    }

    // Increment the score by the given amount
    public void incrementScore(int pts) {
        score += pts;
        lblScore.setText("Score: " + score); // Update the displayed score
    }
}
