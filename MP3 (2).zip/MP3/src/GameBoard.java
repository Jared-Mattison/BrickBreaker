import edu.ncat.brickbreakerbackend.GameProfiles;
import edu.ncat.brickbreakerbackend.Level;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

public class GameBoard extends BorderPane {
    private PlayArea playArea;
    private GameProfiles profiles;
    private int currentLevel;
    private Level[] levels;
    private String profilesFilename;
    private PaddleHandler paddleHandler;
    private Ball ball;
    private Paddle paddle;
    private AnimationTimer animationTimer;
    private int paddleHits;
    private ScorePane scorePane;

    // Constructor to initialize the game board with levels and profiles
    public GameBoard(Level[] levels, GameProfiles profiles, String profilesFilename) {
        this.levels = levels;
        this.profiles = profiles;
        this.profilesFilename = profilesFilename;
        this.currentLevel = 0; // Start at the first level
        this.paddleHits = 0; // Start with zero paddle hits
        scorePane = new ScorePane(); // Create the score display panel


        paddle = new Paddle(600, 700); // Adjust width and height as needed
        ball = new Ball(600, 700, 0);

        playArea = new PlayArea(600, 700, levels[currentLevel]);
        this.setCenter(playArea);
        this.setTop(scorePane);
        paddleHandler = new PaddleHandler();
        this.setOnMouseMoved(paddleHandler); // Listen to mouse movements
        this.setOnMousePressed(event -> handleMouseClick(event));

        animationTimer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                playArea.moveBall();  // Move the ball
                playArea.handleCollisions();  // Handle collisions (walls, paddle, etc.)
                playArea.checkCollisions();  // Check for ball-paddle collision

                if (!ball.isVisible()) {  // If ball is dead and stops the timer
                    this.stop();
                }
            }
        };

    }
    public class PaddleHandler implements EventHandler<MouseEvent> {
        @Override
        public void handle(MouseEvent event) {
            double xLoc = event.getX();
            playArea.movePaddle(xLoc);
        }

    }
    public int getCurrentLevel() {
        return currentLevel;
    }
    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
        playArea = new PlayArea(600, 700, levels[currentLevel]);
        this.setCenter(playArea);
    }
    public PlayArea getPlayArea() {
        return playArea;
    }
    public GameProfiles getProfiles() {
        return profiles;
    }
    public void setProfiles(GameProfiles profiles) {
        this.profiles = profiles;
    }
    public void startGame() {
        ball.resetPosition(paddle.getX() + Paddle.PADDLE_WIDTH / 2, paddle.getY() - ball.getRadius());  // Reset ball position
        ball.launch();// Launch the ball with a random direction
        ball.setBallVisibility(true);
        animationTimer.start();  // Start the animation timer to move the ball
    }

    public void resetGame() {
        ball.setBallVisibility(false);  // Hide the ball
        ball.resetPosition(paddle.getX() + Paddle.PADDLE_WIDTH / 2, paddle.getY() - ball.getRadius());
        ball.setBallVisibility(true);  // Make the ball visible again
        ball.launch();  // Launch the ball with a random direction
        paddleHits = 0;  // Reset paddle hit count
        animationTimer.start();  // Start the animation timer again
    }

    public void handleMouseClick(MouseEvent event) {
        if (!ball.isVisible()) {
            resetGame();  // If the ball is dead then reset the game
        }
    }
}
