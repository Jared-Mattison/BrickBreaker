import edu.ncat.brickbreakerbackend.BrickRow;
import javafx.scene.layout.Pane;
import edu.ncat.brickbreakerbackend.Level;

public class PlayArea extends Pane {
    private Brick[][] bricks; // 2D array to hold the bricks
    public static final int BASE_Y = 100;
    private int paWidth;
    private int paHeight;
    private Paddle paddle;
    private Ball ball;
    private ScorePane scorePane;


    // Constructor for PlayArea, initializes the width, height, and creates the level's bricks and paddle
    public PlayArea(int paHeight, int paWidth, Level level) {
        this.paWidth = paWidth;
        this.paHeight = paHeight;
        this.setPrefSize(paWidth, paHeight);
        scorePane = scorePane;

        createBricks(level); // Call the method to create bricks
        createPaddle();// Call the method to create the paddle
        createBall();

    }
    private void createBricks(Level level) { // Creates and arranges bricks on the play area
        int rows = level.getNumBrickRows();
        int cols = rows > 0 ? level.getBrickRow(0).getBrickMaskLength() : 0;

        bricks = new Brick[rows][cols];

        int spacing = 5; // Spacing between bricks
        int currentY = BASE_Y;

        for (int row = 0; row < rows; row++) {
            BrickRow brickRow = level.getBrickRow(row);
            if (brickRow != null) {
                for (int col = 0; col < cols; col++) {
                    if (brickRow.getBrickMaskValue(col)) {
                        int xLoc = col * (Brick.BRICK_WIDTH + spacing) + 20;
                        Brick brick = new Brick(xLoc, currentY);
                        brick.setColor(brickRow.getColor());
                        brick.setPointValue(brickRow.getPointValue());
                        this.getChildren().add(brick);
                        bricks[row][col] = brick;
                    }
                }
            } else {
                System.err.println("BrickRow" + row + "is null");
            }
            currentY += Brick.BRICK_HEIGHT + spacing;
        }
    }
    private void createPaddle() {
        paddle = new Paddle(paWidth, paHeight);
        this.getChildren().add(paddle);
        this.setOnMouseMoved(event -> movePaddle(event.getX()));
    }
    public void movePaddle(double xLoc) {
        paddle.move(xLoc);
    }
    private void createBall() {
        ball = new Ball(paWidth, paHeight, 0);  // Ball is stationary
        this.getChildren().add(ball);
        setBallVisibility(false); // The ball is hidden
    }

    // Handle ball-wall and ball-paddle collisions
    public void checkCollisions() {
        // Check if the ball is headed down toward the paddle
        if (ball.getBottomEdge() >= paddle.getY() && ball.getTopEdge() <= paddle.getY() + Paddle.PADDLE_HEIGHT) {
            if (ball.getRightEdge() > paddle.getX() && ball.getLeftEdge() < paddle.getX() + Paddle.PADDLE_WIDTH) {
                // Handle collision
                ball.reverseVerticalDirection();  // Reverse the vertical direction to bounce
            } else if (ball.getTopEdge() < paddle.getY()) {
                // Ball is dead so we stop it
                ball.setBallVisibility(false);
            }
        }
    }

    // Handle ball collisions with the walls
    public void handleCollisions() {
        // Check for collision with the walls
        if (ball.getLeftEdge() <= 0 || ball.getRightEdge() >= paWidth) {
            ball.reverseHorizontalDirection();  // Reverse horizontal direction when colliding with walls
        }

        if (ball.getTopEdge() <= 0) {
            ball.reverseVerticalDirection();  // Reverse vertical direction when colliding with the top wall
        }
    }

    // Move the ball at its current speed and direction
    public void moveBall() {
        ball.move();
    }

    // Launch a new ball
    public void newBall() {
        ball.resetPosition(paddle.getX() + Paddle.PADDLE_WIDTH / 2, paddle.getY() - ball.getRadius());
        ball.launch();
        setBallVisibility(true);  // Make the ball visible and start moving
    }

    // Set ball visibility (useful for hiding ball when it’s dead or inactive)
    public void setBallVisibility(boolean visibility) {
        ball.setVisible(visibility);
    }

    // Getters for accessing the ball and paddle
    public Ball getBall() {
        return ball;
    }

    public Paddle getPaddle() {
        return paddle;
    }

    public int getPlayAreaWidth() {
        return paWidth;
    }

    public int getPlayAreaHeight() {
        return paHeight;
    }

}
