import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Paddle extends Rectangle {
    public static final int BASE_Y = 450; //Y coordinate of the paddle
    public static final int PADDLE_WIDTH = 70;
    public static final int PADDLE_HEIGHT = 10;
    private int paHeight;
    private int paWidth;

    public Paddle(int paWidth, int paHeight) { //Constructor to initializes paddles position and size
        super(PADDLE_WIDTH, PADDLE_HEIGHT);
        this.paWidth = paWidth;
        this.paHeight = paHeight;

        double setMiddle = (paWidth - PADDLE_WIDTH) / 2.0; //Centers the paddle
        this.setX(setMiddle);
        this.setY(BASE_Y);
        this.setFill(Color.BLACK);
    }
    //Moves the paddle horizontally
    public void move(double xLoc) {
        double paddleX = xLoc - (PADDLE_WIDTH / 2); // Adjusts the paddles X position
        if (paddleX < 0) { //Stops the paddle from moving out of the left of the window
            paddleX = 0;
        }
        if (paddleX > (paWidth - PADDLE_WIDTH)) { //Stops the paddle from moving out of the right side of the window
            paddleX = paWidth - PADDLE_WIDTH;
        }
        this.setX(paddleX);
    }
}
