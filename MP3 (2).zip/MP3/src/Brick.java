import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Brick extends Rectangle {
    private int pointValue; //Point value that belongs to the brick
    public static final int BRICK_WIDTH = 35;
    public static final int BRICK_HEIGHT = 20;

    public Brick(int xLoc, int yLoc) { //Constructor to initialize a Brick object to specific coordinates
        super(BRICK_WIDTH, BRICK_HEIGHT); //Calls the parent class which is Rectangle
        this.setX(xLoc); //Sets x and y location
        this.setY(yLoc);
        this.setFill(Color.DARKGREEN); //fill color is red
        this.setStroke(Color.BLACK);//border color is black
    }

    public static int getBrickWidth() {
        return BRICK_WIDTH; //returns width of the brick
    }

    public static int getBrickHeight() {
        return BRICK_HEIGHT; //returns height of the brick
    }

    public int getPointValue() {
        return pointValue;
    }

    public void setPointValue(int pointValue) {
        this.pointValue = pointValue;
    }
    public void setColor(Color color) {
        this.setFill(color);
    }
    public Color getColor() {
        return (Color) this.getFill();
    }
}
